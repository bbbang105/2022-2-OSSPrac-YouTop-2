class stack:
    def __init__(self):  # 스택 객체 생성
        self.items = []
    def push(self, item):  # 스택 요소 추가 push(.append())
        self.items.append(item)
    def pop(self):   # 스택 요소 삭제 pop()
        return self.items.pop()

acc = stack()
str = input().split()
x = 0

for c in str:
    x = 0
    a1 = 0
    a2 = 0
    if c == '+':
        x = acc.pop() + acc.pop()
        acc.push(x)
    elif c == '*':
        x = acc.pop() * acc.pop()
        acc.push(x)
    elif c == '-':
        a1 = acc.pop()
        a2 = acc.pop()
        x = a2 - a1
        acc.push(x)
    elif c == '/':
        a1 = acc.pop()
        a2 = acc.pop()
        x = a2 / a1
        acc.push(x)
    else:
        c = int(c)    
        acc.push(c)

x = acc.pop()
print(x)